<?php

// ul.net account data
$user["user"] = 'userid/useralias';
$user["pass"] = 'password';

?>